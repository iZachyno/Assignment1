__version__ = "1.1.8"

from .annotations.images import Image
from .annotations.images import CVImage
from .annotations.images import PillowImage